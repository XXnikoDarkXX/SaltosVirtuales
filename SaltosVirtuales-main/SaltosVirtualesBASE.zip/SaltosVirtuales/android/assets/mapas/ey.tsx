<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="ey" tilewidth="16" tileheight="16" tilecount="1500" columns="50">
 <image source="patrones/Candy expansion/preview.png" width="800" height="480"/>
</tileset>
