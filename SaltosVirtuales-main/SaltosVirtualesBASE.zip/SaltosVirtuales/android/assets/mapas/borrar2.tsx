<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="borrar2" tilewidth="16" tileheight="16" tilecount="1830" columns="61">
 <image source="patrones/Candy expansion/sheet.png" width="980" height="490"/>
</tileset>
