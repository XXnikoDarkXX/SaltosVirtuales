package actores;

public enum Movimiento {

    SALTO;
}
