package actores;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;

import Otros.Constantes;

public class Jugador extends Actor {

    private Texture texture;

    private World world;
    private Body body;

    private Fixture fixture;
    private Box2DDebugRenderer renderer;
    private boolean alive = true;

    private boolean jumping = false;

    private boolean mustJump = false;

  public Jugador(World world, Texture texture, Vector2 position) {

         this.world = world;
        this.texture = texture;


        BodyDef def = new BodyDef();
        def.position.set(position);
        def.type = BodyDef.BodyType.DynamicBody;
        body = world.createBody(def);

        // Give it some shape.
        PolygonShape box = new PolygonShape();      // (1) Create the shape.
        box.setAsBox(0.5f, 0.5f);                   // (2) 1x1 meter box.
        fixture = body.createFixture(box, 3);       // (3) Create the fixture.
        fixture.setUserData("player");              // (4) Set the user data.
        box.dispose();                              // (5) Destroy the shape.

        // Set the size to a value that is big enough to be rendered on the screen.
        setSize(Constantes.PIXELS_IN_METERS/0.5f, Constantes.PIXELS_IN_METERS/0.5f);

    }

    @Override
    public void draw(Batch batch, float parentAlpha) {

       setPosition((body.getPosition().x - 0.5f) * Constantes.PIXELS_IN_METERS,
               (body.getPosition().y - 0.5f) * Constantes.PIXELS_IN_METERS);
        batch.draw(texture, getX(), getY(), getWidth(), getHeight());
    }

    /**
     * Fucnion para eliminar el body y fixture
     */
    public void detach() {
        body.destroyFixture(fixture);
        world.destroyBody(body);
    }

    //@Override
  /*  public void act(float delta) {
        //Iniciar un salto si hemos tocado la pantalla
        if (mustJump) {
            mustJump = false;
            jump();

        }
        if (alive) {
            float rapidezY = body.getLinearVelocity().y;
            body.setLinearVelocity(Constantes.PLAYER_SPEED, rapidezY);
        }

        if (jumping) {
            body.applyForceToCenter(0, -Constantes.IMPULSE_JUMP * 1.15f, true);
        }
    }*/

    public void jump() {
        if (!jumping && alive) {
            jumping = true;
            Vector2 position = body.getPosition();

            body.applyLinearImpulse(0, Constantes.IMPULSE_JUMP, position.x, position.y, true);
        }

    }

    public void setJumping(boolean jumping) {
        this.jumping = jumping;
    }

    public void setMustJump(boolean mustJump) {
        this.mustJump = mustJump;
    }

    public boolean isMustJump() {
        return mustJump;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public boolean isAlive() {
        return alive;
    }

    /**
     * Funcion para el seguimiento de la camara
     * @param camara la camara
     */
    public void seguir(OrthographicCamera camara){
        camara.position.x=this.body.getPosition().x;
        camara.position.y=this.body.getPosition().y;
    }
}
