package Otros;

import com.badlogic.gdx.scenes.scene2d.Actor;

public class Suelo extends Actor {

}
