package Otros;

public class Constantes {

    public static final float PIXELS_IN_METERS=45f;
    public static final float IMPULSE_JUMP=0f;
    public static final float PLAYER_SPEED=8f;
}
