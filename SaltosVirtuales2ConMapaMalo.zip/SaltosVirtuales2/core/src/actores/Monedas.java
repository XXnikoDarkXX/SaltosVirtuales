package actores;

public class Monedas {
}
