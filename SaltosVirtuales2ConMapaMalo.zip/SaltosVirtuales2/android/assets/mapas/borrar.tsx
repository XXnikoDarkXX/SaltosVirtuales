<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="borrar" tilewidth="32" tileheight="32" tilecount="375" columns="25">
 <image source="patrones/Candy expansion/preview.png" width="800" height="480"/>
</tileset>
