<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="geometry" tilewidth="16" tileheight="16" tilecount="1806" columns="43">
 <image source="patrones/Base pack/preview.png" width="698" height="675"/>
</tileset>
